package com.smsapp

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PersistableBundle
import android.provider.Telephony
import android.telephony.SmsMessage
import android.widget.Toast
import androidx.core.app.NotificationCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val subId = intent.getIntExtra(
            "subscription",
            intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1)
        )
        val address = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sent = msgs[0].timestampMillis
        val pending = goAsync()
        Thread {
            try {
                val tid = Repo.storeIncoming(ctx, address, body, sent, subId)
                Notifier.show(ctx, tid, address, body, Sims.slotOf(Sims.active(ctx), subId))
                if (Otp.find(body) != null) OtpCleaner.run(ctx)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

// Required by Android for a default SMS app (MMS support comes later).
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {}
}

// Required by Android for a default SMS app ("reply by message" from the call screen).
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

// Receives "sent" and "delivered" results for outgoing messages.
class SendStatusReceiver : BroadcastReceiver() {
    companion object {
        const val SENT = "com.smsapp.SENT"
        const val DELIVERED = "com.smsapp.DELIVERED"
    }

    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        if (id < 0) return
        val code = resultCode
        val action = intent.action
        val pdu = intent.getByteArrayExtra("pdu")
        val format = intent.getStringExtra("format")
        val pending = goAsync()
        Thread {
            try {
                if (action == SENT) {
                    val ok = code == Activity.RESULT_OK
                    Repo.onSent(ctx, id, ok)
                    if (!ok) Handler(Looper.getMainLooper()).post {
                        Toast.makeText(ctx, R.string.send_failed_toast, Toast.LENGTH_LONG).show()
                    }
                } else if (action == DELIVERED) {
                    val st = try {
                        if (pdu != null) {
                            val m = if (format != null) SmsMessage.createFromPdu(pdu, format) else SmsMessage.createFromPdu(pdu)
                            m?.status ?: 0
                        } else if (code == Activity.RESULT_OK) 0 else 64
                    } catch (e: Exception) {
                        0
                    }
                    Repo.onDelivered(ctx, id, st)
                }
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class OtpPurgeReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try {
                OtpCleaner.run(ctx)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

// Optional auto-delete of verification-code messages (hours stored in prefs; 0 = off).
object OtpCleaner {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
    fun hours(ctx: Context): Int = prefs(ctx).getInt("otp_ttl_h", 0)
    fun setHours(ctx: Context, h: Int) {
        prefs(ctx).edit().putInt("otp_ttl_h", h).apply()
    }

    private fun alarmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 77, Intent(ctx, OtpPurgeReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    // Blocking: call from a background thread.
    fun run(ctx: Context) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(app)
        am.cancel(pi)
        val ttl = hours(app) * 3600_000L
        if (ttl <= 0L) return
        val now = System.currentTimeMillis()
        val oldest = Repo.purgeOtps(app, now - ttl) ?: return
        val at = maxOf(oldest + ttl, now + 60_000L)
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi)
        } catch (e: Exception) {
        }
    }
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val code = intent.getStringExtra("code") ?: return
        val clip = ClipData.newPlainText("OTP", code)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
        ctx.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("nid", 0))
        Toast.makeText(ctx, R.string.copied, Toast.LENGTH_SHORT).show()
    }
}

object Notifier {
    private const val CH = "messages"

    fun show(ctx: Context, tid: Long, address: String, body: String, slot: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, ctx.getString(R.string.channel_messages), NotificationManager.IMPORTANCE_HIGH)
        )
        val id = (tid * 8 + slot).toInt()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("thread_id", tid).putExtra("address", address).putExtra("slot", slot),
            flags
        )
        val code = Otp.find(body)
        val sender = Contacts.nameFor(ctx, address) ?: address
        val shownText = if (code != null) "$sender: $body" else body
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(code ?: sender)
            .setContentText(shownText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(shownText))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .setColor(0xFF4F5BD5.toInt())
        if (slot > 0) b.setSubText("SIM $slot")
        code?.let { code ->
            val copy = PendingIntent.getBroadcast(
                ctx, id + 1,
                Intent(ctx, CopyReceiver::class.java).putExtra("code", code).putExtra("nid", id),
                flags
            )
            b.addAction(0, ctx.getString(R.string.copy_code, code), copy)
        }
        nm.notify(id, b.build())
    }

    fun cancel(ctx: Context, tid: Long, slot: Int) {
        ctx.getSystemService(NotificationManager::class.java).cancel((tid * 8 + slot).toInt())
    }

    fun cancelAll(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancelAll()
    }
}
