package com.smsapp

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.BaseColumns
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager

data class Conv(
    val threadId: Long, val address: String, val name: String?, val snippet: String,
    val date: Long, val unread: Int, val slot: Int, val outgoing: Boolean
) {
    val key: Long get() = threadId * 8 + slot.coerceIn(0, 7)
}

object St {
    const val SENDING = 0
    const val SENT = 1
    const val DELIVERED = 2
    const val FAILED = 3
    const val UNDELIVERED = 4

    fun of(type: Int, status: Int, date: Long): Int = when {
        type == 5 -> FAILED
        type == 4 || type == 6 ->
            if (System.currentTimeMillis() - date > 120_000L) FAILED else SENDING
        status >= 64 -> UNDELIVERED
        status == 0 -> DELIVERED
        else -> SENT
    }
}

data class Msg(
    val id: Long, val body: String, val date: Long,
    val outgoing: Boolean, val state: Int, val slot: Int
)

data class Sim(val subId: Int, val slot: Int)
data class Contact(val name: String, val number: String)

object Sims {
    @SuppressLint("MissingPermission")
    fun active(ctx: Context): List<Sim> = try {
        ctx.getSystemService(SubscriptionManager::class.java)?.activeSubscriptionInfoList.orEmpty()
            .map { Sim(it.subscriptionId, it.simSlotIndex + 1) }
            .sortedBy { it.slot }
    } catch (e: Exception) {
        emptyList()
    }

    fun slotOf(sims: List<Sim>, subId: Int): Int = sims.firstOrNull { it.subId == subId }?.slot ?: 0
    fun defaultSub(): Int = SubscriptionManager.getDefaultSmsSubscriptionId()
}

object Contacts {
    @Volatile private var list: List<Contact>? = null
    @Volatile private var byKey: Map<String, String> = emptyMap()

    fun keyOf(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    fun all(ctx: Context): List<Contact> {
        list?.let { return it }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val out = ArrayList<Contact>()
        val map = HashMap<String, String>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " COLLATE NOCASE"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val p = c.getString(1) ?: continue
                    out.add(Contact(n, p))
                    val k = keyOf(p)
                    if (k.isNotEmpty()) map.putIfAbsent(k, n)
                }
            }
        } catch (e: Exception) {
        }
        byKey = map
        list = out
        return out
    }

    fun nameFor(ctx: Context, address: String): String? {
        if (address.any { it.isLetter() }) return null
        all(ctx)
        val k = keyOf(address)
        return if (k.isEmpty()) null else byKey[k]
    }

    fun refresh() {
        list = null
    }
}

object Otp {
    private val keywords = Regex(
        "(code|otp|pin|passcode|password|verif|one[- ]time|رمز|كود|تحقق|التحقق|مرور)",
        RegexOption.IGNORE_CASE
    )
    private val number = Regex("(?<![\\d+])(\\d{3}[- ]\\d{3}|\\d{4,8})(?!\\d)")

    fun find(body: String): String? {
        if (!keywords.containsMatchIn(body)) return null
        return number.find(body)?.value?.filter { it.isDigit() }
    }
}

object Repo {
    private val SMS = Telephony.Sms.CONTENT_URI
    private const val THREAD = "thread_id"
    private const val READ = "read"

    fun conversations(ctx: Context, sims: List<Sim>): List<Conv> {
        val first = LinkedHashMap<Long, Conv>()
        val unread = HashMap<Long, Int>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(THREAD, "address", "body", "date", "type", READ, "sub_id"),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(4)
                    if (type == 3) continue
                    val tid = c.getLong(0)
                    val slot = Sims.slotOf(sims, c.getInt(6))
                    val k = tid * 8 + slot.coerceIn(0, 7)
                    if (type == 1 && c.getInt(5) == 0) unread[k] = (unread[k] ?: 0) + 1
                    if (!first.containsKey(k)) {
                        first[k] = Conv(
                            tid, c.getString(1) ?: "", null, c.getString(2) ?: "",
                            c.getLong(3), 0, slot, type != 1
                        )
                    }
                }
            }
        } catch (e: Exception) {
        }
        return first.values.map {
            it.copy(name = Contacts.nameFor(ctx, it.address), unread = unread[it.key] ?: 0)
        }
    }

    fun messages(ctx: Context, tid: Long, slot: Int, sims: List<Sim>): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(BaseColumns._ID, "body", "date", "type", "sub_id", "status"),
                "$THREAD=?", arrayOf(tid.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 1500) {
                    val type = c.getInt(3)
                    if (type == 3) continue
                    val sl = Sims.slotOf(sims, c.getInt(4))
                    if (sl != slot) continue
                    out.add(
                        Msg(c.getLong(0), c.getString(1) ?: "", c.getLong(2), type != 1, St.of(type, c.getInt(5), c.getLong(2)), sl)
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context, subId: Int): SmsManager = when {
        subId < 0 -> SmsManager.getDefault()
        Build.VERSION.SDK_INT >= 31 -> ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
        else -> SmsManager.getSmsManagerForSubscriptionId(subId)
    }

    private fun statusIntent(ctx: Context, action: String, id: Long, part: Int): PendingIntent {
        val i = Intent(ctx, SendStatusReceiver::class.java).setAction(action)
            .setData(Uri.parse("smsstatus://$id/$part")).putExtra("id", id)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val code = ((id % 50000).toInt() * 16 + part) * 2 + (if (action == SendStatusReceiver.DELIVERED) 1 else 0)
        return PendingIntent.getBroadcast(ctx, code, i, flags)
    }

    fun send(ctx: Context, address: String, text: String, subId: Int): Long {
        val tid = threadFor(ctx, address)
        val v = ContentValues().apply {
            put("address", address); put("body", text); put("date", System.currentTimeMillis())
            put(READ, 1); put("seen", 1); put("type", 4); put(THREAD, tid)
            if (subId >= 0) put("sub_id", subId)
        }
        var id = -1L
        try {
            ctx.contentResolver.insert(SMS, v)?.let { id = ContentUris.parseId(it) }
        } catch (e: Exception) {
        }
        try {
            val sm = smsManager(ctx, subId)
            val parts = sm.divideMessage(text)
            if (parts.size > 1) {
                val sent = ArrayList<PendingIntent?>()
                val dlv = ArrayList<PendingIntent?>()
                for (n in parts.indices) {
                    sent.add(if (id >= 0) statusIntent(ctx, SendStatusReceiver.SENT, id, n) else null)
                    dlv.add(if (id >= 0 && n == parts.size - 1) statusIntent(ctx, SendStatusReceiver.DELIVERED, id, n) else null)
                }
                sm.sendMultipartTextMessage(address, null, parts, sent, dlv)
            } else {
                sm.sendTextMessage(
                    address, null, text,
                    if (id >= 0) statusIntent(ctx, SendStatusReceiver.SENT, id, 0) else null,
                    if (id >= 0) statusIntent(ctx, SendStatusReceiver.DELIVERED, id, 0) else null
                )
            }
        } catch (e: Exception) {
            onSent(ctx, id, false)
        }
        return tid
    }

    fun onSent(ctx: Context, id: Long, ok: Boolean) {
        if (id < 0) return
        try {
            val v = ContentValues()
            if (ok) {
                v.put("type", 2)
                ctx.contentResolver.update(SMS, v, "_id=? AND type IN (4,6)", arrayOf(id.toString()))
            } else {
                v.put("type", 5)
                ctx.contentResolver.update(SMS, v, "_id=?", arrayOf(id.toString()))
            }
        } catch (e: Exception) {
        }
    }

    // pduStatus: 0..31 delivered, 32..63 still pending, 64+ failed.
    fun onDelivered(ctx: Context, id: Long, pduStatus: Int) {
        if (id < 0 || (pduStatus in 32..63)) return
        try {
            val v = ContentValues().apply { put("status", if (pduStatus >= 64) 64 else 0) }
            ctx.contentResolver.update(SMS, v, "_id=?", arrayOf(id.toString()))
        } catch (e: Exception) {
        }
    }

    fun deleteMessages(ctx: Context, ids: Collection<Long>) {
        ids.chunked(400).forEach { chunk ->
            try {
                ctx.contentResolver.delete(SMS, "_id IN (" + chunk.joinToString(",") + ")", null)
            } catch (e: Exception) {
            }
        }
    }

    fun deleteConversations(ctx: Context, keys: Set<Long>, sims: List<Sim>) {
        val ids = ArrayList<Long>()
        val threads = keys.map { it / 8 }.toSet()
        for (tid in threads) {
            try {
                ctx.contentResolver.query(
                    SMS, arrayOf(BaseColumns._ID, "sub_id"), "$THREAD=?", arrayOf(tid.toString()), null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val slot = Sims.slotOf(sims, c.getInt(1)).coerceIn(0, 7)
                        if ((tid * 8 + slot) in keys) ids.add(c.getLong(0))
                    }
                }
            } catch (e: Exception) {
            }
        }
        deleteMessages(ctx, ids)
        keys.forEach { Notifier.cancel(ctx, it / 8, (it % 8).toInt()) }
    }

    fun storeIncoming(ctx: Context, address: String, body: String, sent: Long, subId: Int): Long {
        val tid = threadFor(ctx, address)
        val v = ContentValues().apply {
            put("address", address); put("body", body); put("date", System.currentTimeMillis())
            put("date_sent", sent); put(READ, 0); put("seen", 0); put(THREAD, tid)
            if (subId >= 0) put("sub_id", subId)
        }
        try {
            ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
        } catch (e: Exception) {
        }
        return tid
    }

    private fun threadFor(ctx: Context, address: String): Long =
        try {
            Telephony.Threads.getOrCreateThreadId(ctx, address)
        } catch (e: Exception) {
            0L
        }

    private fun readValues() = ContentValues().apply { put(READ, 1); put("seen", 1) }

    fun markAllRead(ctx: Context) {
        try {
            ctx.contentResolver.update(SMS, readValues(), "$READ=0", null)
        } catch (e: Exception) {
        }
        try {
            ctx.contentResolver.update(Telephony.Mms.CONTENT_URI, readValues(), "$READ=0", null)
        } catch (e: Exception) {
        }
        Notifier.cancelAll(ctx)
    }

    fun markRead(ctx: Context, tid: Long, slot: Int, sims: List<Sim>) {
        val ids = ArrayList<Long>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(BaseColumns._ID, "sub_id"), "$THREAD=? AND $READ=0", arrayOf(tid.toString()), null
            )?.use { c ->
                while (c.moveToNext()) if (Sims.slotOf(sims, c.getInt(1)) == slot) ids.add(c.getLong(0))
            }
            if (ids.isNotEmpty()) {
                ctx.contentResolver.update(SMS, readValues(), "_id IN (" + ids.joinToString(",") + ")", null)
            }
        } catch (e: Exception) {
        }
        Notifier.cancel(ctx, tid, slot)
    }
}
