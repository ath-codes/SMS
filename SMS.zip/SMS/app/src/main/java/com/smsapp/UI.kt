package com.smsapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Theme ----------

@Composable
fun SmsTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFF8E9BFF), onPrimary = Color(0xFF0B0F2A),
        primaryContainer = Color(0xFF2B3272), onPrimaryContainer = Color(0xFFE6E8FF),
        background = Color(0xFF0F1115), onBackground = Color(0xFFE6E8EE),
        surface = Color(0xFF0F1115), onSurface = Color(0xFFE6E8EE),
        surfaceVariant = Color(0xFF1B1F27), onSurfaceVariant = Color(0xFF9AA1B0)
    ) else lightColorScheme(
        primary = Color(0xFF4F5BD5), onPrimary = Color.White,
        primaryContainer = Color(0xFF4F5BD5), onPrimaryContainer = Color.White,
        background = Color(0xFFF7F8FC), onBackground = Color(0xFF14161C),
        surface = Color(0xFFF7F8FC), onSurface = Color(0xFF14161C),
        surfaceVariant = Color(0xFFEBEDF5), onSurfaceVariant = Color(0xFF6A7080)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private val ContentDir = TextStyle(textDirection = TextDirection.Content)

fun slotColor(slot: Int): Color = when (slot) {
    1 -> Color(0xFF3D8BFF)
    2 -> Color(0xFFFF8A3D)
    else -> Color(0xFF3DBE8B)
}

private val SimShape = GenericShape { s, _ ->
    val c = s.width * 0.34f
    moveTo(0f, 0f)
    lineTo(s.width - c, 0f)
    lineTo(s.width, c)
    lineTo(s.width, s.height)
    lineTo(0f, s.height)
    close()
}

// ---------- Small pieces ----------

@Composable
fun SimBadge(slot: Int, h: Dp, modifier: Modifier = Modifier) {
    if (slot <= 0) return
    val col = slotColor(slot)
    Box(
        modifier
            .size(h * 0.8f, h)
            .clip(SimShape)
            .background(MaterialTheme.colorScheme.background)
            .background(col.copy(alpha = 0.22f))
            .border(1.2.dp, col, SimShape),
        contentAlignment = Alignment.Center
    ) {
        Text(slot.toString(), color = col, fontSize = (h.value * 0.5f).sp, fontWeight = FontWeight.Bold)
    }
}

private val avatarColors = listOf(0xFF6C7BFF, 0xFF3DBE8B, 0xFFFF8A3D, 0xFFE45C8B, 0xFF3D9BE0, 0xFF9B6CFF).map { Color(it) }

fun initial(name: String?, address: String): String =
    (name ?: address).firstOrNull { it.isLetter() }?.uppercase() ?: "#"

@Composable
fun Avatar(text: String, address: String, size: Dp) {
    val col = avatarColors[(address.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(Modifier.size(size).clip(CircleShape).background(col.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
        Text(text, color = col, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

fun fmtTime(ms: Long): String {
    val now = System.currentTimeMillis()
    val pattern = when {
        DateUtils.isToday(ms) -> "HH:mm"
        now - ms < 6 * 86400000L -> "EEE"
        Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.YEAR) ==
            Calendar.getInstance().get(Calendar.YEAR) -> "d MMM"
        else -> "d MMM yy"
    }
    return SimpleDateFormat(pattern, Locale.ENGLISH).format(Date(ms))
}

fun fmtStamp(ms: Long): String {
    val p = if (DateUtils.isToday(ms)) "HH:mm" else "d MMM, HH:mm"
    return SimpleDateFormat(p, Locale.ENGLISH).format(Date(ms))
}

fun copyText(ctx: Context, s: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("SMS", s))
    Toast.makeText(ctx, R.string.copied, Toast.LENGTH_SHORT).show()
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---------- Composer (text box + SIM badge + send) ----------

@Composable
fun Composer(
    sims: List<Sim>, subId: Int, onSub: (Int) -> Unit,
    text: String, onText: (String) -> Unit, canSend: Boolean, onSend: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val slot = Sims.slotOf(sims, subId)
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Row(
            Modifier.weight(1f).heightIn(min = 50.dp).clip(RoundedCornerShape(26.dp))
                .background(cs.surfaceVariant).padding(start = 18.dp, end = 6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            BasicTextField(
                value = text, onValueChange = onText,
                modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp, textDirection = TextDirection.Content),
                cursorBrush = SolidColor(cs.primary), maxLines = 6,
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) Text(stringResource(R.string.type_message), color = cs.onSurfaceVariant, fontSize = 16.sp)
                        inner()
                    }
                }
            )
            if (slot > 0) {
                Box(
                    Modifier.clip(CircleShape).clickable(enabled = sims.size > 1) {
                        val i = sims.indexOfFirst { it.subId == subId }
                        onSub(sims[(i + 1).mod(sims.size)].subId)
                    }.padding(10.dp)
                ) { SimBadge(slot, 24.dp) }
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(50.dp).clip(CircleShape)
                .background(if (canSend) cs.primary else cs.surfaceVariant)
                .clickable(enabled = canSend, onClick = onSend),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, tint = if (canSend) cs.onPrimary else cs.onSurfaceVariant)
        }
    }
}

// ---------- Screens ----------

@Composable
fun App(vm: MainVM) {
    val s = vm.screen
    BackHandler(enabled = s !is Screen.Home) { vm.screen = Screen.Home }
    when (s) {
        Screen.Home -> Home(vm)
        is Screen.Chat -> Chat(vm, s)
        is Screen.NewMsg -> NewMsg(vm, s)
    }
}

@Composable
fun Home(vm: MainVM) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val unread = vm.convs.sumOf { it.unread }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 10.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.app_name), fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(enabled = unread > 0, onClick = {
                    vm.markAllRead()
                    Toast.makeText(ctx, R.string.all_read, Toast.LENGTH_SHORT).show()
                }) { Text("\u2713\u2713  " + stringResource(R.string.mark_all_read)) }
            }
            if (vm.loaded && vm.convs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.no_messages), color = cs.onSurfaceVariant)
                }
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 110.dp)) {
                    items(vm.convs, key = { it.threadId }) { c -> ConvRow(c) { vm.openThread(c.threadId, c.address) } }
                }
            }
        }
        FloatingActionButton(
            onClick = { vm.openNew("", "") },
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp),
            containerColor = cs.primary, contentColor = cs.onPrimary, shape = RoundedCornerShape(20.dp)
        ) { Icon(Icons.Default.Add, null) }
    }
}

@Composable
fun ConvRow(c: Conv, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val prefix = stringResource(R.string.you_prefix)
    val hasUnread = c.unread > 0
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Avatar(initial(c.name, c.address), c.address, 50.dp)
            SimBadge(c.slot, 19.dp, Modifier.align(Alignment.BottomEnd).offset(4.dp, 3.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    c.name ?: c.address, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp, fontWeight = if (hasUnread) FontWeight.Bold else FontWeight.Medium
                )
                val t = remember(c.date) { fmtTime(c.date) }
                Text(t, fontSize = 12.sp, color = if (hasUnread) cs.primary else cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (c.outgoing) prefix else "") + c.snippet.replace('\n', ' '),
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp, style = ContentDir,
                    color = if (hasUnread) cs.onSurface else cs.onSurfaceVariant
                )
                if (hasUnread) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.defaultMinSize(22.dp, 22.dp).clip(CircleShape).background(cs.primary).padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (c.unread > 99) "99+" else c.unread.toString(), color = cs.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun Chat(vm: MainVM, s: Screen.Chat) {
    val conv = vm.convs.firstOrNull { it.threadId == s.id }
    var chosen by remember(s.id, s.address) { mutableStateOf<Int?>(null) }
    var text by rememberSaveable(s.id, s.address) { mutableStateOf("") }
    val sub = chosen ?: vm.pickSub(vm.msgs.firstOrNull()?.slot ?: 0)
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(conv?.name ?: s.address) { vm.screen = Screen.Home }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), reverseLayout = true,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(vm.msgs, key = { it.id }) { Bubble(it) }
        }
        Composer(
            vm.sims, sub, { chosen = it }, text, { text = it }, text.isNotBlank(),
            { vm.send(s.address, text.trim(), sub); text = "" }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(m: Msg) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val out = m.outgoing
    val bg = if (out) cs.primaryContainer else cs.surfaceVariant
    val fg = if (out) cs.onPrimaryContainer else cs.onSurface
    Box(Modifier.fillMaxWidth(), contentAlignment = if (out) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = 300.dp)
                .clip(RoundedCornerShape(20.dp, 20.dp, if (out) 6.dp else 20.dp, if (out) 20.dp else 6.dp))
                .background(bg)
                .combinedClickable(onClick = {}, onLongClick = { copyText(ctx, m.body) })
                .padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            Text(m.body, color = fg, fontSize = 15.5.sp, style = ContentDir)
            Row(Modifier.align(Alignment.End).padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                SimBadge(m.slot, 13.dp)
                if (m.slot > 0) Spacer(Modifier.width(5.dp))
                val t = remember(m.date) { fmtStamp(m.date) }
                Text(t, color = fg.copy(alpha = 0.65f), fontSize = 11.sp)
                if (m.failed) Text("  !", color = Color(0xFFFF5C5C), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun NewMsg(vm: MainVM, s: Screen.NewMsg) {
    val cs = MaterialTheme.colorScheme
    var to by rememberSaveable { mutableStateOf(s.to) }
    var text by rememberSaveable { mutableStateOf(s.body) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    val sub = chosen ?: vm.pickSub(0)
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (to.isEmpty()) fr.requestFocus() }
    val sugg = remember(to, vm.contacts) {
        if (to.isBlank()) emptyList()
        else vm.contacts.filter { it.name.contains(to, true) || it.number.contains(to) }
            .distinctBy { Contacts.keyOf(it.number) }.take(8)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.new_message)) { vm.screen = Screen.Home }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.to), color = cs.onSurfaceVariant, fontSize = 15.sp)
            Spacer(Modifier.width(14.dp))
            BasicTextField(
                value = to, onValueChange = { to = it }, singleLine = true,
                modifier = Modifier.weight(1f).focusRequester(fr),
                textStyle = TextStyle(color = cs.onSurface, fontSize = 17.sp),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )
        }
        HorizontalDivider(color = cs.surfaceVariant)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(sugg, key = { it.name + it.number }) { c ->
                Row(
                    Modifier.fillMaxWidth().clickable { to = c.number }.padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(initial(c.name, c.number), c.number, 40.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(c.number, fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
        Composer(
            vm.sims, sub, { chosen = it }, text, { text = it }, to.isNotBlank() && text.isNotBlank(),
            { vm.sendNew(to.trim(), text.trim(), sub) }
        )
    }
}

@Composable
fun Setup(hasPerms: Boolean, onPerms: () -> Unit, onDefault: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SimBadge(1, 56.dp)
            SimBadge(2, 56.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.setup_title), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.setup_body), textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onPerms, enabled = !hasPerms, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp)) {
            Text((if (hasPerms) "\u2713  " else "1  ") + stringResource(R.string.step_access), fontSize = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onDefault, enabled = hasPerms, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp)) {
            Text("2  " + stringResource(R.string.step_default), fontSize = 16.sp)
        }
    }
}
