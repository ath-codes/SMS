package com.smsapp

import android.Manifest
import android.app.Application
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Home : Screen
    data class Chat(val id: Long, val address: String) : Screen
    data class NewMsg(val to: String, val body: String) : Screen
}

class MainVM(app: Application) : AndroidViewModel(app) {
    var screen by mutableStateOf<Screen>(Screen.Home)
    var convs by mutableStateOf<List<Conv>>(emptyList())
    var msgs by mutableStateOf<List<Msg>>(emptyList())
    var sims by mutableStateOf<List<Sim>>(emptyList())
    var contacts by mutableStateOf<List<Contact>>(emptyList())
    var loaded by mutableStateOf(false)

    private val ctx get() = getApplication<Application>()
    private var job: Job? = null

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            reload()
        }
    }

    init {
        try {
            ctx.contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, observer)
        } catch (e: Exception) {
        }
    }

    override fun onCleared() {
        ctx.contentResolver.unregisterContentObserver(observer)
    }

    fun reload() {
        job?.cancel()
        job = viewModelScope.launch {
            delay(80)
            val s = screen
            val result = withContext(Dispatchers.IO) {
                val sm = Sims.active(ctx)
                val cs = Repo.conversations(ctx, sm)
                if (s is Screen.Chat && cs.any { it.threadId == s.id && it.unread > 0 }) {
                    Repo.markThreadRead(ctx, s.id)
                }
                val ms = if (s is Screen.Chat) Repo.messages(ctx, s.id, sm) else emptyList()
                Triple(cs, ms, sm)
            }
            convs = result.first
            msgs = result.second
            sims = result.third
            loaded = true
            if (contacts.isEmpty()) contacts = withContext(Dispatchers.IO) { Contacts.all(ctx) }
        }
    }

    fun pickSub(slotHint: Int): Int =
        sims.firstOrNull { it.slot == slotHint }?.subId
            ?: Sims.defaultSub().takeIf { d -> sims.any { it.subId == d } }
            ?: sims.firstOrNull()?.subId
            ?: -1

    fun openThread(id: Long, address: String) {
        msgs = emptyList()
        screen = Screen.Chat(id, address)
        reload()
    }

    fun openNew(to: String, body: String) {
        screen = Screen.NewMsg(to, body)
    }

    fun send(address: String, text: String, subId: Int) {
        viewModelScope.launch(Dispatchers.IO) { Repo.send(ctx, address, text, subId) }
    }

    fun sendNew(address: String, text: String, subId: Int) {
        viewModelScope.launch {
            val tid = withContext(Dispatchers.IO) { Repo.send(ctx, address, text, subId) }
            openThread(tid, address)
        }
    }

    fun markAllRead() {
        viewModelScope.launch(Dispatchers.IO) { Repo.markAllRead(ctx) }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()
    private var hasPerms by mutableStateOf(false)
    private var isDefault by mutableStateOf(false)
    private var skipped by mutableStateOf(false)
    private var diag by mutableStateOf("")

    private val required = arrayOf(
        Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_PHONE_STATE
    )

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            Contacts.refresh()
            refresh()
        }
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        refresh()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            SmsTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        if (hasPerms && (isDefault || skipped)) App(vm)
                        else Setup(hasPerms, diag, { askPerms() }, { askDefault() }, { skipped = true; vm.reload() })
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        hasPerms = required.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val pkg = try { Telephony.Sms.getDefaultSmsPackage(this) } catch (e: Exception) { null }
        val viaRole = Build.VERSION.SDK_INT >= 29 && try {
            getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_SMS)
        } catch (e: Exception) { false }
        val viaSecure = try {
            Settings.Secure.getString(contentResolver, "sms_default_application") == packageName
        } catch (e: Exception) { false }
        isDefault = pkg == packageName || viaRole || viaSecure
        diag = "default=$pkg role=$viaRole secure=$viaSecure perms=$hasPerms"
        if (hasPerms && (isDefault || skipped)) vm.reload()
    }

    private fun askPerms() {
        val all = mutableListOf(*required)
        all += Manifest.permission.READ_CONTACTS
        all += Manifest.permission.RECEIVE_MMS
        all += Manifest.permission.RECEIVE_WAP_PUSH
        if (Build.VERSION.SDK_INT >= 33) all += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(all.toTypedArray())
    }

    private fun askDefault() {
        try {
            val i = if (Build.VERSION.SDK_INT >= 29) {
                getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
            } else {
                Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            }
            roleLauncher.launch(i)
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        val tid = i.getLongExtra("thread_id", -1L)
        val addr = i.getStringExtra("address")
        if (tid >= 0 && addr != null) {
            vm.openThread(tid, addr)
            return
        }
        if (i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_SEND) {
            val num = (Uri.decode(i.data?.schemeSpecificPart.orEmpty()) ?: "").substringBefore('?')
            val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            vm.openNew(num, body)
        }
    }
}
