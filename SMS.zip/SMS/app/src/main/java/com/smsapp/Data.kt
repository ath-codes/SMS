package com.smsapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.BaseColumns
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager

data class Conv(
    val threadId: Long, val address: String, val name: String?, val snippet: String,
    val date: Long, val unread: Int, val slot: Int, val outgoing: Boolean
) {
    val key: Long get() = threadId * 8 + slot.coerceIn(0, 7)
}

data class Msg(
    val id: Long, val body: String, val date: Long,
    val outgoing: Boolean, val failed: Boolean, val slot: Int
)

data class Sim(val subId: Int, val slot: Int)
data class Contact(val name: String, val number: String)

object Sims {
    @SuppressLint("MissingPermission")
    fun active(ctx: Context): List<Sim> = try {
        ctx.getSystemService(SubscriptionManager::class.java)?.activeSubscriptionInfoList.orEmpty()
            .map { Sim(it.subscriptionId, it.simSlotIndex + 1) }
            .sortedBy { it.slot }
    } catch (e: Exception) {
        emptyList()
    }

    fun slotOf(sims: List<Sim>, subId: Int): Int = sims.firstOrNull { it.subId == subId }?.slot ?: 0
    fun defaultSub(): Int = SubscriptionManager.getDefaultSmsSubscriptionId()
}

object Contacts {
    @Volatile private var list: List<Contact>? = null
    @Volatile private var byKey: Map<String, String> = emptyMap()

    fun keyOf(n: String): String = n.filter { it.isDigit() }.takeLast(9)

    fun all(ctx: Context): List<Contact> {
        list?.let { return it }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val out = ArrayList<Contact>()
        val map = HashMap<String, String>()
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " COLLATE NOCASE"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val p = c.getString(1) ?: continue
                    out.add(Contact(n, p))
                    val k = keyOf(p)
                    if (k.isNotEmpty()) map.putIfAbsent(k, n)
                }
            }
        } catch (e: Exception) {
        }
        byKey = map
        list = out
        return out
    }

    fun nameFor(ctx: Context, address: String): String? {
        if (address.any { it.isLetter() }) return null
        all(ctx)
        val k = keyOf(address)
        return if (k.isEmpty()) null else byKey[k]
    }

    fun refresh() {
        list = null
    }
}

object Otp {
    private val keywords = Regex(
        "(code|otp|pin|passcode|password|verif|one[- ]time|رمز|كود|تحقق|التحقق|مرور)",
        RegexOption.IGNORE_CASE
    )
    private val number = Regex("(?<![\\d+])(\\d{3}[- ]\\d{3}|\\d{4,8})(?!\\d)")

    fun find(body: String): String? {
        if (!keywords.containsMatchIn(body)) return null
        return number.find(body)?.value?.filter { it.isDigit() }
    }
}

object Repo {
    private val SMS = Telephony.Sms.CONTENT_URI
    private const val THREAD = "thread_id"
    private const val READ = "read"

    fun conversations(ctx: Context, sims: List<Sim>): List<Conv> {
        val first = LinkedHashMap<Long, Conv>()
        val unread = HashMap<Long, Int>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(THREAD, "address", "body", "date", "type", READ, "sub_id"),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(4)
                    if (type == 3) continue
                    val tid = c.getLong(0)
                    val slot = Sims.slotOf(sims, c.getInt(6))
                    val k = tid * 8 + slot.coerceIn(0, 7)
                    if (type == 1 && c.getInt(5) == 0) unread[k] = (unread[k] ?: 0) + 1
                    if (!first.containsKey(k)) {
                        first[k] = Conv(
                            tid, c.getString(1) ?: "", null, c.getString(2) ?: "",
                            c.getLong(3), 0, slot, type != 1
                        )
                    }
                }
            }
        } catch (e: Exception) {
        }
        return first.values.map {
            it.copy(name = Contacts.nameFor(ctx, it.address), unread = unread[it.key] ?: 0)
        }
    }

    fun messages(ctx: Context, tid: Long, slot: Int, sims: List<Sim>): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(BaseColumns._ID, "body", "date", "type", "sub_id"),
                "$THREAD=?", arrayOf(tid.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 1500) {
                    val type = c.getInt(3)
                    if (type == 3) continue
                    val sl = Sims.slotOf(sims, c.getInt(4))
                    if (sl != slot) continue
                    out.add(
                        Msg(c.getLong(0), c.getString(1) ?: "", c.getLong(2), type != 1, type == 5, sl)
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context, subId: Int): SmsManager = when {
        subId < 0 -> SmsManager.getDefault()
        Build.VERSION.SDK_INT >= 31 -> ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
        else -> SmsManager.getSmsManagerForSubscriptionId(subId)
    }

    fun send(ctx: Context, address: String, text: String, subId: Int): Long {
        var ok = true
        try {
            val sm = smsManager(ctx, subId)
            val parts = sm.divideMessage(text)
            if (parts.size > 1) sm.sendMultipartTextMessage(address, null, parts, null, null)
            else sm.sendTextMessage(address, null, text, null, null)
        } catch (e: Exception) {
            ok = false
        }
        val tid = threadFor(ctx, address)
        val v = ContentValues().apply {
            put("address", address); put("body", text); put("date", System.currentTimeMillis())
            put(READ, 1); put("seen", 1); put("type", if (ok) 2 else 5); put(THREAD, tid)
            if (subId >= 0) put("sub_id", subId)
        }
        try {
            ctx.contentResolver.insert(SMS, v)
        } catch (e: Exception) {
        }
        return tid
    }

    fun storeIncoming(ctx: Context, address: String, body: String, sent: Long, subId: Int): Long {
        val tid = threadFor(ctx, address)
        val v = ContentValues().apply {
            put("address", address); put("body", body); put("date", System.currentTimeMillis())
            put("date_sent", sent); put(READ, 0); put("seen", 0); put(THREAD, tid)
            if (subId >= 0) put("sub_id", subId)
        }
        try {
            ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
        } catch (e: Exception) {
        }
        return tid
    }

    private fun threadFor(ctx: Context, address: String): Long =
        try {
            Telephony.Threads.getOrCreateThreadId(ctx, address)
        } catch (e: Exception) {
            0L
        }

    private fun readValues() = ContentValues().apply { put(READ, 1); put("seen", 1) }

    fun markAllRead(ctx: Context) {
        try {
            ctx.contentResolver.update(SMS, readValues(), "$READ=0", null)
        } catch (e: Exception) {
        }
        try {
            ctx.contentResolver.update(Telephony.Mms.CONTENT_URI, readValues(), "$READ=0", null)
        } catch (e: Exception) {
        }
        Notifier.cancelAll(ctx)
    }

    fun markRead(ctx: Context, tid: Long, slot: Int, sims: List<Sim>) {
        val ids = ArrayList<Long>()
        try {
            ctx.contentResolver.query(
                SMS, arrayOf(BaseColumns._ID, "sub_id"), "$THREAD=? AND $READ=0", arrayOf(tid.toString()), null
            )?.use { c ->
                while (c.moveToNext()) if (Sims.slotOf(sims, c.getInt(1)) == slot) ids.add(c.getLong(0))
            }
            if (ids.isNotEmpty()) {
                ctx.contentResolver.update(SMS, readValues(), "_id IN (" + ids.joinToString(",") + ")", null)
            }
        } catch (e: Exception) {
        }
        Notifier.cancel(ctx, tid, slot)
    }
}
