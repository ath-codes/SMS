package com.smsapp

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.PersistableBundle
import android.provider.Telephony
import android.widget.Toast
import androidx.core.app.NotificationCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return
        val subId = intent.getIntExtra(
            "subscription",
            intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1)
        )
        val address = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sent = msgs[0].timestampMillis
        val pending = goAsync()
        Thread {
            try {
                val tid = Repo.storeIncoming(ctx, address, body, sent, subId)
                Notifier.show(ctx, tid, address, body, Sims.slotOf(Sims.active(ctx), subId))
            } finally {
                pending.finish()
            }
        }.start()
    }
}

// Required by Android for a default SMS app (MMS support comes later).
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {}
}

// Required by Android for a default SMS app ("reply by message" from the call screen).
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val code = intent.getStringExtra("code") ?: return
        val clip = ClipData.newPlainText("OTP", code)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
        ctx.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("nid", 0))
        Toast.makeText(ctx, R.string.copied, Toast.LENGTH_SHORT).show()
    }
}

object Notifier {
    private const val CH = "messages"

    fun show(ctx: Context, tid: Long, address: String, body: String, slot: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, ctx.getString(R.string.channel_messages), NotificationManager.IMPORTANCE_HIGH)
        )
        val id = tid.toInt()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("thread_id", tid).putExtra("address", address),
            flags
        )
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(Contacts.nameFor(ctx, address) ?: address)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .setColor(0xFF4F5BD5.toInt())
        if (slot > 0) b.setSubText("SIM $slot")
        Otp.find(body)?.let { code ->
            val copy = PendingIntent.getBroadcast(
                ctx, id + 1,
                Intent(ctx, CopyReceiver::class.java).putExtra("code", code).putExtra("nid", id),
                flags
            )
            b.addAction(0, ctx.getString(R.string.copy_code, code), copy)
        }
        nm.notify(id, b.build())
    }

    fun cancel(ctx: Context, tid: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(tid.toInt())
    }

    fun cancelAll(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancelAll()
    }
}
