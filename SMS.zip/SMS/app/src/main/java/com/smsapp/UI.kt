package com.smsapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Theme ----------

@Composable
fun SmsTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFF8E9BFF), onPrimary = Color(0xFF0B0F2A),
        primaryContainer = Color(0xFF2B3272), onPrimaryContainer = Color(0xFFE6E8FF),
        background = Color(0xFF0F1115), onBackground = Color(0xFFE6E8EE),
        surface = Color(0xFF0F1115), onSurface = Color(0xFFE6E8EE),
        surfaceVariant = Color(0xFF1B1F27), onSurfaceVariant = Color(0xFF9AA1B0)
    ) else lightColorScheme(
        primary = Color(0xFF4F5BD5), onPrimary = Color.White,
        primaryContainer = Color(0xFF4F5BD5), onPrimaryContainer = Color.White,
        background = Color(0xFFF7F8FC), onBackground = Color(0xFF14161C),
        surface = Color(0xFFF7F8FC), onSurface = Color(0xFF14161C),
        surfaceVariant = Color(0xFFEBEDF5), onSurfaceVariant = Color(0xFF6A7080)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private val ContentDir = TextStyle(textDirection = TextDirection.Content)

fun slotColor(slot: Int): Color = when (slot) {
    1 -> Color(0xFF3D8BFF)
    2 -> Color(0xFFFF8A3D)
    else -> Color(0xFF3DBE8B)
}

private val SimShape = GenericShape { s, _ ->
    val c = s.width * 0.34f
    moveTo(0f, 0f)
    lineTo(s.width - c, 0f)
    lineTo(s.width, c)
    lineTo(s.width, s.height)
    lineTo(0f, s.height)
    close()
}

// ---------- Small pieces ----------

// Double-check icon (sent + delivered).
val DoneAllIcon: ImageVector by lazy {
    ImageVector.Builder("DoneAll", 24.dp, 24.dp, 24f, 24f).addPath(
        pathData = PathParser().parsePathString(
            "M18,7l-1.41,-1.41 -6.34,6.34 1.41,1.41L18,7zM22.24,5.59L11.66,16.17 7.48,12l-1.41,1.41L11.66,19l12,-12 -1.42,-1.41zM0.41,13.41L6,19l1.41,-1.41L1.83,12 0.41,13.41z"
        ).toNodes(),
        fill = SolidColor(Color.Black)
    ).build()
}

// SIM-card badge. The digit is drawn centered by its real glyph bounds, so it never gets clipped.
@Composable
fun SimBadge(slot: Int, h: Dp, modifier: Modifier = Modifier, filled: Boolean = false) {
    if (slot <= 0) return
    val col = slotColor(slot)
    val bg = MaterialTheme.colorScheme.background
    val look = if (filled) Modifier.background(col)
    else Modifier.background(bg).background(col.copy(alpha = 0.14f)).border(1.dp, col.copy(alpha = 0.55f), SimShape)
    val digit = slot.toString()
    val ink = (if (filled) Color.White else col.copy(alpha = 0.95f)).toArgb()
    val paint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    }
    val rect = remember { Rect() }
    Canvas(modifier.size(h * 0.8f, h).clip(SimShape).then(look)) {
        paint.color = ink
        paint.textSize = size.height * 0.6f
        paint.getTextBounds(digit, 0, digit.length, rect)
        drawIntoCanvas {
            it.nativeCanvas.drawText(digit, size.width * 0.46f, size.height / 2f - rect.exactCenterY(), paint)
        }
    }
}

private val avatarColors = listOf(0xFF6C7BFF, 0xFF3DBE8B, 0xFFFF8A3D, 0xFFE45C8B, 0xFF3D9BE0, 0xFF9B6CFF).map { Color(it) }

fun initial(name: String?, address: String): String =
    (name ?: address).firstOrNull { it.isLetter() }?.uppercase() ?: "#"

// The letter stays centered; the SIM badge sits on the corner, outside the circle, with a ring cut-out.
@Composable
fun Avatar(
    text: String, address: String, size: Dp, slot: Int = 0,
    selected: Boolean = false, ring: Color = Color.Unspecified
) {
    val cs = MaterialTheme.colorScheme
    val col = avatarColors[(address.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(Modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(if (selected) cs.primary else col.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Icon(Icons.Default.Check, null, tint = cs.onPrimary, modifier = Modifier.size(size * 0.5f))
            else Text(text, color = col, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.36f).sp)
        }
        if (slot > 0) {
            Box(
                Modifier.align(Alignment.BottomEnd).offset(3.dp, 3.dp).clip(SimShape)
                    .background(if (ring == Color.Unspecified) cs.background else ring).padding(2.dp)
            ) { SimBadge(slot, 18.dp, filled = true) }
        }
    }
}

fun fmtTime(ms: Long): String {
    val now = System.currentTimeMillis()
    val pattern = when {
        DateUtils.isToday(ms) -> "HH:mm"
        now - ms < 6 * 86400000L -> "EEE"
        Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.YEAR) ==
            Calendar.getInstance().get(Calendar.YEAR) -> "d MMM"
        else -> "d MMM yy"
    }
    return SimpleDateFormat(pattern, Locale.ENGLISH).format(Date(ms))
}

fun fmtStamp(ms: Long): String {
    val p = if (DateUtils.isToday(ms)) "HH:mm" else "d MMM, HH:mm"
    return SimpleDateFormat(p, Locale.ENGLISH).format(Date(ms))
}

fun copyText(ctx: Context, s: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("SMS", s))
    Toast.makeText(ctx, R.string.copied, Toast.LENGTH_SHORT).show()
}

@Composable
fun SelectBar(count: Int, onClose: () -> Unit, actions: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
        Text(count.toString(), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 6.dp))
        actions()
    }
}

@Composable
fun ConfirmDialog(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text, fontSize = 16.sp) },
        confirmButton = { TextButton(onClick = onYes) { Text(stringResource(R.string.yes)) } },
        dismissButton = { TextButton(onClick = onNo) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun TopBar(title: String, slot: Int = 0, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        if (slot > 0) {
            Spacer(Modifier.width(10.dp))
            SimBadge(slot, 16.dp)
        }
    }
}

// ---------- Composer (text box + SIM badge + send) ----------

@Composable
fun Composer(
    sims: List<Sim>, subId: Int, onSub: (Int) -> Unit,
    text: String, onText: (String) -> Unit, canSend: Boolean, onSend: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val slot = Sims.slotOf(sims, subId)
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Row(
            Modifier.weight(1f).heightIn(min = 50.dp).clip(RoundedCornerShape(26.dp))
                .background(cs.surfaceVariant).padding(start = 18.dp, end = 6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            BasicTextField(
                value = text, onValueChange = onText,
                modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                textStyle = TextStyle(color = cs.onSurface, fontSize = 16.sp, textDirection = TextDirection.Content),
                cursorBrush = SolidColor(cs.primary), maxLines = 6,
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) Text(stringResource(R.string.type_message), color = cs.onSurfaceVariant, fontSize = 16.sp)
                        inner()
                    }
                }
            )
            if (slot > 0) {
                Box(
                    Modifier.clip(CircleShape).clickable(enabled = sims.size > 1) {
                        val i = sims.indexOfFirst { it.subId == subId }
                        onSub(sims[(i + 1).mod(sims.size)].subId)
                    }.padding(12.dp)
                ) { SimBadge(slot, 20.dp) }
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(50.dp).clip(CircleShape)
                .background(if (canSend) cs.primary else cs.surfaceVariant)
                .clickable(enabled = canSend, onClick = onSend),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, null, tint = if (canSend) cs.onPrimary else cs.onSurfaceVariant)
        }
    }
}

// ---------- Screens ----------

@Composable
fun App(vm: MainVM) {
    val s = vm.screen
    BackHandler(enabled = s !is Screen.Home) { vm.screen = Screen.Home }
    when (s) {
        Screen.Home -> Home(vm)
        is Screen.Chat -> Chat(vm, s)
        is Screen.NewMsg -> NewMsg(vm, s)
        Screen.Settings -> SettingsScreen(vm)
    }
}

@Composable
fun Home(vm: MainVM) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val unread = vm.convs.sumOf { it.unread }
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var askRead by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    val prefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var bannerOff by remember { mutableStateOf(prefs.getBoolean("bg_banner_off", false)) }
    val ignoring = remember(vm.bgTick) { Bg.ignoring(ctx) }
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }

    if (askRead) ConfirmDialog(
        stringResource(R.string.mark_all_read_confirm),
        onYes = {
            askRead = false
            vm.markAllRead()
            Toast.makeText(ctx, R.string.all_read, Toast.LENGTH_SHORT).show()
        },
        onNo = { askRead = false }
    )
    if (askDelete) ConfirmDialog(
        stringResource(R.string.delete_convs_confirm),
        onYes = { askDelete = false; vm.deleteConvs(sel); sel = emptySet() },
        onNo = { askDelete = false }
    )

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (sel.isEmpty()) {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(start = 22.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.app_name), fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.screen = Screen.Settings }) {
                        Icon(Icons.Default.Settings, stringResource(R.string.settings))
                    }
                    IconButton(enabled = unread > 0, onClick = { askRead = true }) {
                        Icon(DoneAllIcon, stringResource(R.string.mark_all_read))
                    }
                }
            } else {
                SelectBar(sel.size, { sel = emptySet() }) {
                    IconButton(onClick = { askDelete = true }) {
                        Icon(Icons.Default.Delete, stringResource(R.string.delete))
                    }
                }
            }
            if (!ignoring && !bannerOff && sel.isEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant)
                        .clickable { vm.screen = Screen.Settings }
                        .padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.bg_banner), fontSize = 13.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        bannerOff = true
                        prefs.edit().putBoolean("bg_banner_off", true).apply()
                    }) { Icon(Icons.Default.Close, null, Modifier.size(18.dp)) }
                }
            }
            if (vm.loaded && vm.convs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(stringResource(R.string.no_messages), color = cs.onSurfaceVariant)
                }
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 160.dp)) {
                    items(vm.convs, key = { it.key }) { c ->
                        ConvRow(
                            c, c.key in sel,
                            onClick = {
                                if (sel.isNotEmpty()) sel = if (c.key in sel) sel - c.key else sel + c.key
                                else vm.openThread(c.threadId, c.address, c.slot)
                            },
                            onLong = { sel = sel + c.key }
                        )
                    }
                }
            }
        }
        if (sel.isEmpty()) {
            FloatingActionButton(
                onClick = { vm.openNew("", "") },
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 22.dp, bottom = 56.dp),
                containerColor = cs.primary, contentColor = cs.onPrimary, shape = RoundedCornerShape(20.dp)
            ) { Icon(Icons.Default.Add, null) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConvRow(c: Conv, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val prefix = stringResource(R.string.you_prefix)
    val hasUnread = c.unread > 0
    val rowBg = if (selected) cs.primary.copy(alpha = 0.12f).compositeOver(cs.background) else cs.background
    Row(
        Modifier.fillMaxWidth().background(rowBg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(initial(c.name, c.address), c.address, 54.dp, c.slot, selected, rowBg)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    c.name ?: c.address, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp, fontWeight = if (hasUnread) FontWeight.Bold else FontWeight.Medium
                )
                val t = remember(c.date) { fmtTime(c.date) }
                Text(t, fontSize = 12.sp, color = if (hasUnread) cs.primary else cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (c.outgoing) prefix else "") + c.snippet.replace('\n', ' '),
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp, style = ContentDir,
                    color = if (hasUnread) cs.onSurface else cs.onSurfaceVariant
                )
                if (hasUnread) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.defaultMinSize(22.dp, 22.dp).clip(CircleShape).background(cs.primary).padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (c.unread > 99) "99+" else c.unread.toString(), color = cs.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun Chat(vm: MainVM, s: Screen.Chat) {
    val ctx = LocalContext.current
    val conv = vm.convs.firstOrNull { it.threadId == s.id && it.slot == s.slot }
    var chosen by remember(s.id, s.address, s.slot) { mutableStateOf<Int?>(null) }
    var text by rememberSaveable(s.id, s.address, s.slot) { mutableStateOf("") }
    var sel by remember(s.id, s.slot) { mutableStateOf(setOf<Long>()) }
    var askDelete by remember { mutableStateOf(false) }
    val sub = chosen ?: vm.pickSub(s.slot)
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }
    if (askDelete) ConfirmDialog(
        stringResource(R.string.delete_msgs_confirm),
        onYes = { askDelete = false; vm.deleteMsgs(sel); sel = emptySet() },
        onNo = { askDelete = false }
    )
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        if (sel.isEmpty()) {
            TopBar(conv?.name ?: s.address, s.slot) { vm.screen = Screen.Home }
        } else {
            SelectBar(sel.size, { sel = emptySet() }) {
                TextButton(onClick = {
                    copyText(ctx, vm.msgs.filter { it.id in sel }.sortedBy { it.date }.joinToString("\n") { it.body })
                    sel = emptySet()
                }) { Text(stringResource(R.string.copy)) }
                IconButton(onClick = { askDelete = true }) {
                    Icon(Icons.Default.Delete, stringResource(R.string.delete))
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), reverseLayout = true,
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(vm.msgs, key = { it.id }) { m ->
                Bubble(
                    m, m.id in sel,
                    onClick = { if (sel.isNotEmpty()) sel = if (m.id in sel) sel - m.id else sel + m.id },
                    onLong = { sel = if (m.id in sel) sel - m.id else sel + m.id }
                )
            }
        }
        Composer(
            vm.sims, sub, { chosen = it }, text, { text = it }, text.isNotBlank(),
            {
                val t = text.trim()
                if (s.slot == 0 || Sims.slotOf(vm.sims, sub) == s.slot) vm.send(s.address, t, sub)
                else vm.sendNew(s.address, t, sub)
                text = ""
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(m: Msg, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val out = m.outgoing
    val bad = out && (m.state == St.FAILED || m.state == St.UNDELIVERED)
    val bg = if (bad) Color(0xFFB3261E) else if (out) cs.primaryContainer else cs.surfaceVariant
    val fg = if (bad) Color.White else if (out) cs.onPrimaryContainer else cs.onSurface
    Box(
        Modifier.fillMaxWidth()
            .background(if (selected) cs.primary.copy(alpha = 0.16f) else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 2.dp),
        contentAlignment = if (out) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Column(
            Modifier.widthIn(max = 300.dp)
                .clip(RoundedCornerShape(20.dp, 20.dp, if (out) 6.dp else 20.dp, if (out) 20.dp else 6.dp))
                .background(bg)
                .combinedClickable(onClick = onClick, onLongClick = onLong)
                .padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            Text(m.body, color = fg, fontSize = 15.5.sp, style = ContentDir)
            Row(Modifier.align(Alignment.End).padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                val t = remember(m.date) { fmtStamp(m.date) }
                Text(t, color = fg.copy(alpha = 0.65f), fontSize = 11.sp)
                if (out) {
                    Spacer(Modifier.width(5.dp))
                    when (m.state) {
                        St.SENDING -> Text("\u2026", color = fg.copy(alpha = 0.7f), fontSize = 12.sp)
                        St.SENT -> Icon(Icons.Default.Check, null, tint = fg.copy(alpha = 0.7f), modifier = Modifier.size(14.dp))
                        St.DELIVERED -> Icon(DoneAllIcon, null, tint = Color(0xFF8CF0C8), modifier = Modifier.size(16.dp))
                        else -> {
                            Icon(Icons.Default.Warning, null, tint = fg, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(3.dp))
                            Text(
                                stringResource(if (m.state == St.FAILED) R.string.status_failed else R.string.status_undelivered),
                                color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NewMsg(vm: MainVM, s: Screen.NewMsg) {
    val cs = MaterialTheme.colorScheme
    var to by rememberSaveable { mutableStateOf(s.to) }
    var text by rememberSaveable { mutableStateOf(s.body) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    val sub = chosen ?: vm.pickSub(0)
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (to.isEmpty()) fr.requestFocus() }
    val sugg = remember(to, vm.contacts) {
        if (to.isBlank()) emptyList()
        else vm.contacts.filter { it.name.contains(to, true) || it.number.contains(to) }
            .distinctBy { Contacts.keyOf(it.number) }.take(8)
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopBar(stringResource(R.string.new_message)) { vm.screen = Screen.Home }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.to), color = cs.onSurfaceVariant, fontSize = 15.sp)
            Spacer(Modifier.width(14.dp))
            BasicTextField(
                value = to, onValueChange = { to = it }, singleLine = true,
                modifier = Modifier.weight(1f).focusRequester(fr),
                textStyle = TextStyle(color = cs.onSurface, fontSize = 17.sp),
                cursorBrush = SolidColor(cs.primary),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )
        }
        HorizontalDivider(color = cs.surfaceVariant)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(sugg, key = { it.name + it.number }) { c ->
                Row(
                    Modifier.fillMaxWidth().clickable { to = c.number }.padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(initial(c.name, c.number), c.number, 40.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(c.number, fontSize = 13.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
        Composer(
            vm.sims, sub, { chosen = it }, text, { text = it }, to.isNotBlank() && text.isNotBlank(),
            { vm.sendNew(to.trim(), text.trim(), sub) }
        )
    }
}

@Composable
fun Setup(hasPerms: Boolean, diag: String, onPerms: () -> Unit, onDefault: () -> Unit, onSkip: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SimBadge(1, 56.dp)
            SimBadge(2, 56.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.setup_title), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(R.string.setup_body), textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onPerms, enabled = !hasPerms, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp)) {
            Text((if (hasPerms) "\u2713  " else "1  ") + stringResource(R.string.step_access), fontSize = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onDefault, enabled = hasPerms, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(27.dp)) {
            Text("2  " + stringResource(R.string.step_default), fontSize = 16.sp)
        }
        if (hasPerms) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onSkip) { Text(stringResource(R.string.continue_anyway)) }
        }
        Spacer(Modifier.height(20.dp))
        Text(diag, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun SettingRow(num: Int, title: Int, desc: Int, done: Boolean = false, value: String? = null, onClick: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant)
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(32.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            if (done) Icon(Icons.Default.Check, null, tint = cs.primary, modifier = Modifier.size(18.dp))
            else if (num <= 0) Icon(Icons.Default.Delete, null, tint = cs.primary, modifier = Modifier.size(18.dp))
            else Text(num.toString(), color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            Text(stringResource(desc), fontSize = 13.sp, color = cs.onSurfaceVariant)
        }
        if (value != null) {
            Spacer(Modifier.width(8.dp))
            Text(value, color = cs.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        } else if (done) {
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.on), color = cs.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsScreen(vm: MainVM) {
    val ctx = LocalContext.current
    val ignoring = remember(vm.bgTick) { Bg.ignoring(ctx) }
    val x = Bg.isXiaomi
    val off = if (x) 2 else 0
    var ttl by remember { mutableStateOf(OtpCleaner.hours(ctx)) }
    var pick by remember { mutableStateOf(false) }
    if (pick) AlertDialog(
        onDismissRequest = { pick = false },
        title = { Text(stringResource(R.string.set_otp_title), fontSize = 18.sp) },
        text = {
            Column {
                listOf(0, 1, 24, 168).forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            OtpCleaner.setHours(ctx, h)
                            ttl = h
                            pick = false
                            Thread { OtpCleaner.run(ctx) }.start()
                        }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = ttl == h, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(otpLabel(h), fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { pick = false }) { Text(stringResource(R.string.cancel)) } }
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        TopBar(stringResource(R.string.settings)) { vm.screen = Screen.Home }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SettingRow(1, R.string.set_battery_title, R.string.set_battery_desc, ignoring) { Bg.batteryAndroid(ctx) }
            if (x) {
                SettingRow(2, R.string.set_xiaomi_battery_title, R.string.set_xiaomi_battery_desc) { Bg.batteryXiaomi(ctx) }
                SettingRow(3, R.string.set_autostart_title, R.string.set_autostart_desc) { Bg.autostart(ctx) }
            }
            SettingRow(2 + off, R.string.set_notif_title, R.string.set_notif_desc) { Bg.notifications(ctx) }
            SettingRow(3 + off, R.string.set_lock_title, R.string.set_lock_desc)
            SettingRow(0, R.string.set_otp_title, R.string.set_otp_desc, value = otpLabel(ttl)) { pick = true }
        }
    }
}

@Composable
fun otpLabel(h: Int): String = stringResource(
    when (h) {
        1 -> R.string.otp_1h
        24 -> R.string.otp_24h
        168 -> R.string.otp_7d
        else -> R.string.otp_off
    }
)
